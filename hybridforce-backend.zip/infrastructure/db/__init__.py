# Database utilities and session management.
