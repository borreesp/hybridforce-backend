# Infrastructure layer for persistence and external services.
