# Application services and DTOs connecting domain and infrastructure.
