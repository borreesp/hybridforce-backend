# Domain services exposing core calculations.
