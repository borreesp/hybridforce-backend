# Domain package for core entities and logic.
