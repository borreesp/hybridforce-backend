# API adapters exposing FastAPI routers.
