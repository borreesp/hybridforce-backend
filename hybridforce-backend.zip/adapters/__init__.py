# Adapters layer exposes external interfaces (APIs, CLIs, etc.).
